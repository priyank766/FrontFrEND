import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ArrowRight, Palette, Accessibility, Zap, Smartphone, Settings } from "lucide-react";

interface PreferencesFormProps {
  onSubmit: (preferences: UserPreferences) => void;
  onBack: () => void;
  repoUrl: string;
}

export interface UserPreferences {
  improvements: string[];
  theme: string;
  priority: string;
}

const improvementOptions = [
  {
    id: "ui-cleanup",
    label: "UI Cleanups",
    description: "Improve visual hierarchy, spacing, and modern design patterns",
    icon: Palette,
  },
  {
    id: "responsive",
    label: "Responsive Fixes",
    description: "Optimize layouts for mobile and tablet devices",
    icon: Smartphone,
  },
  {
    id: "accessibility",
    label: "Accessibility",
    description: "Add WCAG compliance and screen reader support",
    icon: Accessibility,
  },
  {
    id: "performance",
    label: "Performance",
    description: "Optimize loading times and Core Web Vitals",
    icon: Zap,
  },
];

const themeOptions = [
  { id: "light", label: "Light", description: "Clean and minimal light theme" },
  { id: "dark", label: "Dark", description: "Modern dark theme with good contrast" },
  { id: "neutral", label: "Auto", description: "Adapts to system preference" },
];

export const PreferencesForm = ({ onSubmit, onBack, repoUrl }: PreferencesFormProps) => {
  const [improvements, setImprovements] = useState<string[]>([]);
  const [theme, setTheme] = useState("neutral");
  const [priority, setPriority] = useState("balanced");

  const handleImprovementChange = (improvementId: string, checked: boolean) => {
    if (checked) {
      setImprovements([...improvements, improvementId]);
    } else {
      setImprovements(improvements.filter(id => id !== improvementId));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ improvements, theme, priority });
  };

  const repoName = repoUrl.split("/").pop() || "repository";

  return (
    <section className="min-h-screen py-20 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4 animate-fade-in">
          <h2 className="text-4xl lg:text-5xl font-bold gradient-primary bg-clip-text text-transparent">
            Customize Your Improvements
          </h2>
          <p className="text-xl text-muted-foreground">
            Configure AI analysis settings for <span className="font-mono font-semibold">{repoName}</span>
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Improvement Types */}
            <Card className="glass-card glow-subtle animate-scale-in interactive-glow">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-6 h-6 text-primary" />
                  Improvement Areas
                </CardTitle>
                <CardDescription>
                  Select the types of improvements you want AI to focus on
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {improvementOptions.map((option) => {
                  const IconComponent = option.icon;
                  return (
                    <div
                      key={option.id}
                      className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <Checkbox
                        id={option.id}
                        checked={improvements.includes(option.id)}
                        onCheckedChange={(checked) => 
                          handleImprovementChange(option.id, checked as boolean)
                        }
                        className="mt-1"
                      />
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <IconComponent className="w-4 h-4 text-primary" />
                          <Label 
                            htmlFor={option.id} 
                            className="text-sm font-medium cursor-pointer"
                          >
                            {option.label}
                          </Label>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {option.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Theme & Priority Settings */}
            <div className="space-y-6 animate-slide-in">
              {/* Theme Preference */}
              <Card className="glass-card glow-subtle interactive-glow">
                <CardHeader>
                  <CardTitle>Theme Preference</CardTitle>
                  <CardDescription>
                    Choose the color scheme for your improved frontend
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={theme} onValueChange={setTheme} className="space-y-3">
                    {themeOptions.map((option) => (
                      <div key={option.id} className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                        <RadioGroupItem value={option.id} id={`theme-${option.id}`} />
                        <div className="flex-1">
                          <Label 
                            htmlFor={`theme-${option.id}`} 
                            className="font-medium cursor-pointer"
                          >
                            {option.label}
                          </Label>
                          <p className="text-xs text-muted-foreground">
                            {option.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Priority Setting */}
              <Card className="glass-card glow-subtle interactive-glow">
                <CardHeader>
                  <CardTitle>Improvement Priority</CardTitle>
                  <CardDescription>
                    Set the focus level for AI analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={priority} onValueChange={setPriority} className="space-y-3">
                    <div className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                      <RadioGroupItem value="conservative" id="priority-conservative" />
                      <div className="flex-1">
                        <Label htmlFor="priority-conservative" className="font-medium cursor-pointer">
                          Conservative
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Minimal changes, preserve existing design
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                      <RadioGroupItem value="balanced" id="priority-balanced" />
                      <div className="flex-1">
                        <Label htmlFor="priority-balanced" className="font-medium cursor-pointer">
                          Balanced
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Good mix of improvements without major overhauls
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 p-2 rounded-lg hover:bg-muted/50 transition-colors">
                      <RadioGroupItem value="aggressive" id="priority-aggressive" />
                      <div className="flex-1">
                        <Label htmlFor="priority-aggressive" className="font-medium cursor-pointer">
                          Aggressive
                        </Label>
                        <p className="text-xs text-muted-foreground">
                          Maximum improvements, modern redesign
                        </p>
                      </div>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-between">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onBack}
              className="group"
            >
              <ArrowLeft className="mr-2 w-4 h-4 transition-transform group-hover:-translate-x-1" />
              Back to Repository
            </Button>
            
            <Button 
              type="submit" 
              variant="hero" 
              size="lg"
              disabled={improvements.length === 0}
              className="group"
            >
              Start AI Analysis
              <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover:translate-x-1" />
            </Button>
          </div>
        </form>
      </div>
    </section>
  );
};